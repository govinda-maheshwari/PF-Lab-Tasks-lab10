#include <stdio.h>
#include <string.h>

struct AirFlight {
    int flightCode;
    char fromCity[30];
    char toCity[30];
    char travelDate[20];
    int freeSeats;
};

void displayAll(struct AirFlight list[], int total);
void reserveSeat(struct AirFlight list[], int total);
void searchFlight(struct AirFlight list[], int total);

int main() {
    struct AirFlight myFlights[5];
    int total = 3;

    myFlights[0].flightCode = 201;
    strcpy(myFlights[0].fromCity, "Multan");
    strcpy(myFlights[0].toCity, "Quetta");
    strcpy(myFlights[0].travelDate, "25-11-2026");
    myFlights[0].freeSeats = 40;

    myFlights[1].flightCode = 202;
    strcpy(myFlights[1].fromCity, "Peshawar");
    strcpy(myFlights[1].toCity, "Karachi");
    strcpy(myFlights[1].travelDate, "26-11-2026");
    myFlights[1].freeSeats = 25;

    myFlights[2].flightCode = 203;
    strcpy(myFlights[2].fromCity, "Islamabad");
    strcpy(myFlights[2].toCity, "London");
    strcpy(myFlights[2].travelDate, "27-11-2026");
    myFlights[2].freeSeats = 8;

    int option;

    while (1) {
        printf("\n===== AIRLINE BOOKING SYSTEM =====\n");
        printf("1. Display All Flights\n");
        printf("2. Reserve a Seat\n");
        printf("3. Search Flight by Number\n");
        printf("4. Exit Program\n");
        printf("Please enter your option: ");
        scanf("%d", &option);

        if (option == 1) {
            displayAll(myFlights, total);
        }
        else if (option == 2) {
            reserveSeat(myFlights, total);
        }
        else if (option == 3) {
            searchFlight(myFlights, total);
        }
        else if (option == 4) {
            printf("Thank you for using our system. Good Bye!\n");
            break;
        }
        else {
            printf("Invalid option! Please try again.\n");
        }
    }

    return 0;
}

void displayAll(struct AirFlight list[], int total) {
    printf("\n--- Flight List ---\n");
    for (int i = 0; i < total; i++) {
        printf("\nFlight Code: %d\n", list[i].flightCode);
        printf("Route: %s to %s\n", list[i].fromCity, list[i].toCity);
        printf("Date: %s\n", list[i].travelDate);
        printf("Seats Left: %d\n", list[i].freeSeats);
        printf("--------------------");
    }
}

void reserveSeat(struct AirFlight list[], int total) {
    int code, found = 0;
    printf("\nEnter Flight Code for booking: ");
    scanf("%d", &code);

    for (int i = 0; i < total; i++) {
        if (list[i].flightCode == code) {
            found = 1;
            if (list[i].freeSeats > 0) {
                list[i].freeSeats = list[i].freeSeats - 1;
                printf("Booking Done Successfully!\n");
                printf("Now only %d seats are left in Flight %d.\n", list[i].freeSeats, list[i].flightCode);
            } else {
                printf("Sorry, No seats are available in this flight.\n");
            }
        }
    }

    if (found == 0) {
        printf("No flight found with this code.\n");
    }
}

void searchFlight(struct AirFlight list[], int total) {
    int code, found = 0;
    printf("\nEnter Flight Code to search: ");
    scanf("%d", &code);

    for (int i = 0; i < total; i++) {
        if (list[i].flightCode == code) {
            found = 1;
            printf("\nFlight Found!\n");
            printf("Flight Code: %d\n", list[i].flightCode);
            printf("Route: %s to %s\n", list[i].fromCity, list[i].toCity);
            printf("Date: %s\n", list[i].travelDate);
            printf("Seats Left: %d\n", list[i].freeSeats);
        }
    }

    if (found == 0) {
        printf("Flight not found.\n");
    }
}