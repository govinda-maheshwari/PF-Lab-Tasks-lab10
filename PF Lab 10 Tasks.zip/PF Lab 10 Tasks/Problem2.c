#include <stdio.h>
#include <string.h>

struct Film {
    char name[50];
    char type[30];
    char directorName[50];
    int year;
    float stars;
};

int main() {
    struct Film list[50];
    int count = 0;
    int choice;
    char temp[50];
    int i;
    int found;

    list[0].year = 2023;
    list[0].stars = 8.5;
    strcpy(list[0].name, "Jawan");
    strcpy(list[0].type, "Action");
    strcpy(list[0].directorName, "Atlee");
    count = 1;

    list[1].year = 2022;
    list[1].stars = 9.0;
    strcpy(list[1].name, "TopGun");
    strcpy(list[1].type, "Action");
    strcpy(list[1].directorName, "TomCruise");
    count = 2;

    while (1) {
        printf("\n===== MOVIE SYSTEM =====\n");
        printf("1. Add New Movie\n");
        printf("2. Search by Genre\n");
        printf("3. Show All Movies\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        getchar();

        if (choice == 1) {
            if (count >= 50) {
                printf("List is full.\n");
                continue;
            }
            printf("Enter Title (no space, use _): ");
            scanf("%s", list[count].name);
            printf("Enter Genre: ");
            scanf("%s", list[count].type);
            printf("Enter Director (no space, use _): ");
            scanf("%s", list[count].directorName);
            printf("Enter Release Year: ");
            scanf("%d", &list[count].year);
            printf("Enter Rating out of 10: ");
            scanf("%f", &list[count].stars);
            count = count + 1;
            printf("Movie Added!\n");
        }
        else if (choice == 2) {
            printf("Enter Genre to search: ");
            scanf("%s", temp);
            found = 0;
            for (i = 0; i < count; i++) {
                if (strcmp(list[i].type, temp) == 0) {
                    printf("\nTitle: %s\n", list[i].name);
                    printf("Genre: %s\n", list[i].type);
                    printf("Director: %s\n", list[i].directorName);
                    printf("Year: %d\n", list[i].year);
                    printf("Rating: %.1f\n", list[i].stars);
                    printf("------------------");
                    found = 1;
                }
            }
            if (found == 0) {
                printf("No movie found in this genre.\n");
            }
        }
        else if (choice == 3) {
            printf("\n--- All Movies ---\n");
            for (i = 0; i < count; i++) {
                printf("\nTitle: %s\n", list[i].name);
                printf("Genre: %s\n", list[i].type);
                printf("Director: %s\n", list[i].directorName);
                printf("Year: %d\n", list[i].year);
                printf("Rating: %.1f / 10\n", list[i].stars);
                printf("------------------");
            }
            if (count == 0) {
                printf("No movies yet.\n");
            }
        }
        else if (choice == 4) {
            printf("Bye Bye!\n");
            break;
        }
        else {
            printf("Wrong choice, try again.\n");
        }
    }

    return 0;
}